def read_cfg():
    cfg = {}

    n = int(input("Enter number of production rules: "))

    for i in range(n):
        rule = input("Enter rule (e.g. S -> AB | a): ")

        left, right = rule.split("->")
        left = left.strip()
        right = right.strip()

        productions = [p.strip() for p in right.split("|")]

        if left not in cfg:
            cfg[left] = []

        cfg[left].extend(productions)

    return cfg