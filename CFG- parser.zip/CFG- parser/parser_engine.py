def is_non_terminal(symbol, cfg):
    return symbol in cfg


def parse(current, target, cfg):
    if current == target:
        return True

    if len(current) > len(target):
        return False

    for i in range(len(current)):
        symbol = current[i]

        if symbol in cfg:
            for production in cfg[symbol]:
                new_string = (
                    current[:i] +
                    production +
                    current[i+1:]
                )

                if parse(new_string, target, cfg):
                    return True

    return False